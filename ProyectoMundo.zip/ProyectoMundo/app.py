# Importa la clase Flask y la función render_template del paquete flask
from flask import Flask, render_template

# Crea una instancia de la aplicación Flask
app = Flask(__name__)

# Define la ruta principal de la aplicación ("/")
@app.route('/')
def index():
    """Página principal que muestra el mensaje 'Hola Mundo'."""
    # Renderiza la plantilla HTML 'index.html'
    return render_template('index.html')

# Comprueba si el archivo se está ejecutando directamente
if __name__ == '__main__':
    # Inicia la aplicación Flask en modo depuración
    app.run(debug=True)